package com.dealsapp.coupon.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignConfig {
    // Additional Feign configuration if needed
}